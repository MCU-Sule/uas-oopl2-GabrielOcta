module com.gabriel.uas_1972037_gabrieloctamahardika {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.naming;
    requires java.sql;
    requires java.persistence;
    requires org.hibernate.orm.core;


    opens com.gabriel.uas_1972037_gabrieloctamahardika to javafx.fxml;
    exports com.gabriel.uas_1972037_gabrieloctamahardika;
    exports com.gabriel.entity;
}